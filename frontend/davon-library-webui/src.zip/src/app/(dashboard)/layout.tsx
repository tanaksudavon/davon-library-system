'use client';

import { usePathname } from 'next/navigation';
import DashboardSidebar from '@/components/dashboard/DashboardSidebar';
import ProtectedRoute from '@/components/auth/ProtectedRoute';

export default function DashboardLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const pathname = usePathname();
    
    // Tüm yollar için debug amaçlı log
    console.log('[DashboardLayout] Current path:', pathname);
    
    // Books ve Profile sayfaları herkes için erişilebilir olmalı
    // Sadece admin paneli, users ve diğer sayfalar admin olmalı
    const isAdminOnlyPath = pathname === '/dashboard' || 
                            pathname.includes('/users') || 
                            pathname.includes('/dashboard/');
    
    // Admin gerektiren sayfalar için admin rolü, diğerleri için rol kontrolü yapma
    const requiredRole = isAdminOnlyPath ? 'admin' : undefined;
    
    console.log('[DashboardLayout] isAdminOnlyPath:', isAdminOnlyPath);
    console.log('[DashboardLayout] requiredRole:', requiredRole);
    
    return (
        <ProtectedRoute requiredRole={requiredRole}>
            <div className="flex h-screen bg-gray-100">
                <DashboardSidebar />
                <main className="flex-1 overflow-y-auto">
                    {children}
                </main>
            </div>
        </ProtectedRoute>
    );
} 